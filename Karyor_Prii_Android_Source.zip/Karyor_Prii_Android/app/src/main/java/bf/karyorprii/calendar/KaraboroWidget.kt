package bf.karyorprii.calendar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import java.time.LocalDate

class KaraboroWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == IntentActions.DATE_CHANGED ||
            intent.action == IntentActions.TIME_SET ||
            intent.action == IntentActions.TIMEZONE_CHANGED ||
            intent.action == IntentActions.BOOT_COMPLETED) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(android.content.ComponentName(context, KaraboroWidget::class.java))
                .forEach { update(context, manager, it) }
        }
    }

    private fun update(context: Context, manager: AppWidgetManager, id: Int) {
        val today = LocalDate.now()
        val views = RemoteViews(context.packageName, R.layout.karaboro_widget).apply {
            setTextViewText(R.id.widget_day, KaraboroDay.forDate(today))
            setTextViewText(R.id.widget_date, KaraboroDay.formattedDate(today))
        }
        manager.updateAppWidget(id, views)
    }

    private object IntentActions {
        const val DATE_CHANGED = "android.intent.action.DATE_CHANGED"
        const val TIME_SET = "android.intent.action.TIME_SET"
        const val TIMEZONE_CHANGED = "android.intent.action.TIMEZONE_CHANGED"
        const val BOOT_COMPLETED = "android.intent.action.BOOT_COMPLETED"
    }
}
