package bf.karyorprii.calendar

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object KaraboroDay {
    private val cycle = listOf("Tchangué", "Gbetchan", "Nafou", "Kourya", "Dôchi")
    private val anchor = LocalDate.of(2026, 11, 21) // 21 novembre 2026 = Dôchi

    fun forDate(date: LocalDate): String {
        val offset = ChronoUnit.DAYS.between(anchor, date)
        val index = Math.floorMod(4L + offset, cycle.size.toLong()).toInt()
        return cycle[index]
    }

    fun formattedDate(date: LocalDate): String {
        val months = listOf("janvier", "février", "mars", "avril", "mai", "juin",
            "juillet", "août", "septembre", "octobre", "novembre", "décembre")
        return "%02d %s %d".format(date.dayOfMonth, months[date.monthValue - 1], date.year)
    }
}
