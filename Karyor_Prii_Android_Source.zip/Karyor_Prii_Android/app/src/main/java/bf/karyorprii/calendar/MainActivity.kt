package bf.karyorprii.calendar

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import java.time.LocalDate

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val today = LocalDate.now()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "KARYOR PRII"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val day = TextView(this).apply {
            text = KaraboroDay.forDate(today)
            textSize = 34f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 8)
        }
        val date = TextView(this).apply {
            text = KaraboroDay.formattedDate(today)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val cycle = TextView(this).apply {
            text = "\nCycle traditionnel\nTchangué – Gbetchan – Nafou – Kourya – Dôchi"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val motto = TextView(this).apply {
            text = "\nNotre temps, notre culture, notre identité. 🌅"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        layout.addView(title); layout.addView(day); layout.addView(date)
        layout.addView(cycle); layout.addView(motto)
        setContentView(layout)
    }
}
