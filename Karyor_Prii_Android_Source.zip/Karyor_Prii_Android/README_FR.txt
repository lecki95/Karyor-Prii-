KARYOR PRII — Projet Android natif (source)

Fonctions incluses dans cette première base :
- Calcul du cycle de cinq jours : Tchangué, Gbetchan, Nafou, Kourya, Dôchi.
- Date d’ancrage : 21 novembre 2026 = Dôchi.
- Calcul local, sans connexion Internet.
- Widget d’écran d’accueil affichant le jour Karaboro et la date grégorienne.
- Mise à jour du widget lors du changement de date, de l’heure, du fuseau horaire et au démarrage du téléphone.

IMPORTANT
Ce dossier est le code source d’un projet Android Studio, pas encore un fichier APK installable.
Pour produire l’APK : ouvrir ce dossier dans Android Studio, laisser Gradle synchroniser, puis
choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
L’APK sera généré dans app/build/outputs/apk/debug/.

Pour ajouter le widget sur le téléphone après installation :
1. Appuyer longuement sur un espace vide de l’écran d’accueil.
2. Ouvrir Widgets.
3. Chercher KARYOR PRII.
4. Maintenir le widget et le déposer sur l’écran d’accueil.

Aucune autorisation Internet n’est demandée : le calcul du jour et de la date est entièrement local.

Cette version constitue le socle du widget et du calcul hors ligne. Le calendrier mensuel complet
et la liste juridiquement vérifiée des jours fériés et commémorations du Burkina Faso restent à
intégrer dans une prochaine étape.
